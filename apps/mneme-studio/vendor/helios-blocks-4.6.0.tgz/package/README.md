# @helios/blocks

Wiki Block System：Helios 项目群前端 UI 范式（Block / Frame / Theme）。React 19 + Tailwind v4 + Radix。

> ⚠️ 本仓源码从发布版 dist 的 sourcemap 还原而来，请先读 [`RECONSTRUCTION.md`](./RECONSTRUCTION.md)。
> 本轮设计审视修复见 [`CHANGES.md`](./CHANGES.md)。

## 安装 / 构建
```bash
npm install
npm run build       # tsup + inject-use-client + build:css
npm run typecheck
```

## 用法
```ts
import { OButton, OFormField, OKPICard } from '@helios/blocks';
import '@helios/blocks/styles.css';
// 或单主题：import '@helios/blocks/themes/cyberpunk.css';
```

## 主题
cyberpunk · professional · academic · terminal-dark/light/neon/paper · zen · mneme-friendly · tide-bloomberg
（`data-theme` + `data-mode` + `data-density` 三轴）。
